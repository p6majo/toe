package com.p6majo.info.bundesliga;

public class Torward extends Spieler {

    public Torward(String name, int startnummer) {
        super(name, startnummer);
    }


}
