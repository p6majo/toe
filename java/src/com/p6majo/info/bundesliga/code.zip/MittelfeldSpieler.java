package com.p6majo.info.bundesliga;

public class MittelfeldSpieler extends Spieler {
    public MittelfeldSpieler(String name, int startnummer) {
        super(name, startnummer);
    }
}
