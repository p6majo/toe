package com.p6majo.info.bundesliga;

public class Stuermer extends Spieler {
    public Stuermer(String name, int startnummer) {
        super(name, startnummer);
    }
}
