package com.p6majo.info.bundesliga;

public class Verteidiger extends Spieler{
    public Verteidiger(String name, int startnummer) {
        super(name, startnummer);
    }
}
